package com.example.androidapplication

import java.io.Serializable

data class Name(val name: String) : Serializable